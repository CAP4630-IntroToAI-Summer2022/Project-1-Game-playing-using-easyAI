Examples Of Use
===============

In these pages you will find a few examples of use of easyAI: 

.. toctree::
   :maxdepth: 1
   
   quick_example
   games
   integrate
