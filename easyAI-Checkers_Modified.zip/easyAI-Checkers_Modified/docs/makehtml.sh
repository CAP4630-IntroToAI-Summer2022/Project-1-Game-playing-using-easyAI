make html
firefox ../../docs/html/index.html
