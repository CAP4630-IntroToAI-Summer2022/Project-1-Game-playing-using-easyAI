from .TicTacToe import TicTacToe
from .ConnectFour import ConnectFour
from .Knights import Knights
from .GameOfBones import GameOfBones
from .Nim import Nim
from .Cram import Cram
from .ThreeMusketeers import ThreeMusketeers
from .AweleTactical import AweleTactical
