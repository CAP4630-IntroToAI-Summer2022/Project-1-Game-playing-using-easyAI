Installation
=============

if you have ``pip`` installed, type this in a terminal ::
    
    sudo pip install easyAI
    
Otherwise, dowload the source code (for instance on Github), unzip everything into one folder and in this folder, in a terminal, type ::
    
    sudo python setup.py install

Additionnally you will need to install Numpy to be able to run some of the examples.